﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UserGUI : MonoBehaviour
{
    public IUserAction userAction;
    public string gameMessage;
    public int points;

    private void Start()
    {
        points = 0;
        gameMessage = "";
        userAction = SSDirector.GetInstance().CurrentScenceController as IUserAction;
    }
    public void SetMessage(string gameMessage)
    {
        this.gameMessage = gameMessage;
    }

    public void SetPoints(int points)
    {
        this.points = points;
    }
    void OnGUI(){
        GUIStyle style = new GUIStyle();
        style.normal.textColor = Color.white;
        style.fontSize = 25;
        GUIStyle style2 = new GUIStyle();
        style2.normal.textColor = Color.white;
        style2.fontSize = 40;
        GUI.Label(new Rect(0, 0, 100, 50), "Points: " + points, style);
        GUI.Label(new Rect(380, 100, 80, 200), gameMessage, style);

        if (GUI.Button(new Rect(20, 50, 100, 40), "Start"))
        {
            userAction.Start();
        }
        if (Input.GetButtonDown("Fire1"))
        {
            userAction.Hit(Input.mousePosition);
        }
    }
}
