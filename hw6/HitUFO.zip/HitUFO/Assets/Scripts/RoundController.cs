﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RoundController : MonoBehaviour
{
    FirstController controller;
    IActionManager actionManager;
    DiskFactory diskFactory;
    UserGUI userGUI;
    int[] roundDisks;
    int round;
    int sendCount;
    float time;
    int points;
    // Start is called before the first frame update
    void Start()
    {
        controller = (FirstController)SSDirector.GetInstance().CurrentScenceController;
        actionManager = Singleton<PhysisActionManager>.Instance;
        diskFactory = Singleton<DiskFactory>.Instance;
        userGUI = Singleton<UserGUI>.Instance;
        sendCount = 0;
        round = 0;
        time = 0;
        points = 0;
        roundDisks = new int[] { 3, 5, 7, 9, 11 };
    }

    void Update()
    {
        time += Time.deltaTime;
        if(time > 1)
        {
            time = 0;
            for(int i = 0; i < 5 && sendCount < roundDisks[round]; ++i)
            {
                sendCount++;
                SendDisk();
            }
            if(sendCount == roundDisks[round] && round == roundDisks.Length - 1)
            {
                userGUI.SetMessage("Game Over!");
            }
            if (sendCount == roundDisks[round] && round < roundDisks.Length - 1)
            {
                sendCount = 0;
                round++;
            }
        }
    }
    public void Reset()
    {
        sendCount = 0;
        round = 0;
        time = 0;
        points = 0;
    }
 
    public void Record(Disk disk)
    {
        points += disk.points;
    }

    public int GetPoints()
    {
        return points;
    }

    public void SendDisk()
    {
        GameObject disk = diskFactory.GetDisk(round);
        disk.transform.position = new Vector3(-disk.GetComponent<Disk>().direction.x * 6, UnityEngine.Random.Range(0f, 8f), 0);
        disk.SetActive(true);
        actionManager.Fly(disk, disk.GetComponent<Disk>().speed, disk.GetComponent<Disk>().direction);
    }


}
