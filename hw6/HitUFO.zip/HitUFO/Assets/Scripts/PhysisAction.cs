﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PhysisAction : SSAction
{
    float speed;
    Vector3 direction;

    public static PhysisAction GetSSAction(Vector3 direction, float speed)
    {
           PhysisAction action = ScriptableObject.CreateInstance<PhysisAction>();
            action.speed = speed;
            action.direction = direction;
            return action;
    }

    // Start is called before the first frame update
    public override void Start()
    {
        gameObject.GetComponent<Rigidbody>().isKinematic = false;
        gameObject.GetComponent<Rigidbody>().velocity = speed * direction;
    }

    // Update is called once per frame
    public override void Update()
    {
        if (this.transform.position.y < -5)
        {
            this.destroy = true;
            this.enable = false;
            this.callback.SSActionEvent(this);
        }
    }
}
