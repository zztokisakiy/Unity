﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Disk : MonoBehaviour
{
    public float speed;         
    public int points;         
    public Vector3 direction;   
}
